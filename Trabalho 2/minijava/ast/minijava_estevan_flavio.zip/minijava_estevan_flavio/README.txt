Alunos: Estevan Gladstone do N. Melo
	Flávio Ribeiro Neto

Obs.: O aluno Romeu Pires abandonou a matéria. O Flávio é o novo integrante da dupla.
